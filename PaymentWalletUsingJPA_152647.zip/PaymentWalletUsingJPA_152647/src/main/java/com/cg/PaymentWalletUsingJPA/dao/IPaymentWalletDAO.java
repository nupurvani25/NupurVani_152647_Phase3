package com.cg.PaymentWalletUsingJPA.dao;

import java.util.List;

import com.cg.PaymentWalletUsingJPA.beans.Customer;

public interface IPaymentWalletDAO {
	public float showBalance();
	public boolean depositAmount(float amount);
	public boolean withdrawAmount(float amount);
	public boolean loginAccount(String uName,String uPassword);
	public boolean fundTransfer(String uname,float amount);
	public String printTransaction();
	public boolean addWalletDetails(Customer customer);
}
